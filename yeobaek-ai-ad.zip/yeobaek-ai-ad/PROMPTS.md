# PROMPTS — 여백 YEOBAEK

그록(및 대체 도구)에 바로 붙여넣어 쓸 수 있는 프롬프트 모음입니다.
**모든 이미지 프롬프트 말미에 아래 스타일 토큰을 붙여 화풍 일관성을 유지하세요.**

## 공통 스타일 토큰 (Style Token)

```
muted ivory and sage palette, soft natural window light, minimal Korean aesthetic, frosted-glass product, 35mm film grain, cinematic, 16:9
```

---

## 0. 마스터 병 (master-bottle) — 가장 먼저 생성

> 이 1장을 확정한 뒤, 모든 씬 I2V의 시작 프레임/레퍼런스로 재사용합니다.

```
Product shot of a minimalist frosted-glass sparkling tonic bottle, slim cylindrical silhouette, soft sage-green label with thin serif Korean wordmark, condensation droplets, studio softbox light on a misty ivory background, premium minimal, muted ivory and sage palette, 35mm film grain, 16:9
```

파일: `assets/images/master_bottle.png`

---

## 씬 1 — 기 · 문제 제시

**이미지 (Grok Imagine)**
```
High-angle shot of a crowded Seoul subway platform at morning rush hour, blurred commuters rushing past, cold fluorescent lighting, desaturated muted gray tones, sense of pressure and haste, cinematic 35mm film grain, 16:9
```

**영상 (Grok Imagine Video 1.5 · I2V)**
```
Subtle fast motion of the crowd moving past, slight camera shake, cold and tense atmosphere, ambient subway noise and muffled crowd murmur, 2-3 second clip
```

파일: `s01_city_rush.png` → `s01_city_rush.mp4`

---

## 씬 2 — 승 · 전환

**이미지 (Grok Imagine)** — *마스터 병 레퍼런스 사용*
```
Close-up, a hand reaching for the frosted-glass sparkling tonic bottle on a soft ivory table, sage green label, rising carbonation bubbles, soft natural window light, shallow depth of field, [공통 스타일 토큰]
```

**영상 (Grok I2V)**
```
Slow push-in as the hand picks up the bottle, carbonation bubbles rising gently, time feels like it slows down, soft fizz sound effect, calm transition, 2-3 second clip
```

파일: `s02_pickup.png` → `s02_pickup.mp4`

### 프롬프트 수정 전/후 로그

| 구분 | 내용 |
|---|---|
| **수정 전** | `close up of a soda bottle with bubbles on a table` |
| **문제** | 콜라풍 일반 탄산음료로 출력 → 미니멀·보태니컬 톤과 불일치, 라벨이 화려하고 색이 쨍함, 씬마다 병 디자인이 달라져 일관성 깨짐 |
| **수정 후** | 색 팔레트 토큰 고정 + 라벨/소재 명시(frosted-glass, sage label) + 마스터 병 레퍼런스 첨부 + 광선 지정 + "손이 집는" 동작 추가 |
| **결과** | 콜라풍 → 차분한 프리미엄 토닉으로 교정, 병 디자인 통일(일관성 확보), 자연광으로 '쉼' 정서 강화 |

---

## 씬 3 — 전 · 해결

**이미지 (Grok Imagine)**
```
Medium close-up silhouette of a person taking a sip and exhaling with eyes closed by a misty window, warm natural light blooming, color gently shifting from gray to sage and ivory, calm and serene, [공통 스타일 토큰]
```

**영상 (Grok I2V)**
```
Gentle exhale, warm light blooming across the frame, color reviving from gray to sage and ivory, serene and breathable mood, soft ambient pad, 2-3 second clip
```

**한국어 내레이션 (ElevenLabs / Typecast TTS)** — 차분한 톤
```
바쁜 하루에, 여백 한 모금.
```

파일: `s03_sip_breath.png` → `s03_sip_breath.mp4` · `s03_vo_ko.wav`

---

## 씬 4 — 결 · 브랜드 인지

**이미지 (Grok Imagine)** — *로고/CTA 텍스트는 편집 단계 오버레이 권장*
```
Centered product hero shot of the frosted sparkling tonic bottle on a misty ivory background, soft studio light, premium minimal, generous negative space at top and bottom for text overlay, [공통 스타일 토큰]
```

**영상 (Grok I2V)**
```
Minimal motion, micro carbonation bubbles looping, subtle light shift, product stays centered and stable, soft brand chime, 2-3 second clip
```

**편집 단계 텍스트 오버레이 (CapCut/DaVinci)**
- 상단 로고: `여백 YEOBAEK` (얇은 명조)
- 하단 슬로건: `오늘의 여백을 마시다`
- CTA: `편의점에서 만나요`

파일: `s04_hero_logo.png` → `s04_hero_logo.mp4` · `s04_brand_sting.wav`

---

## 보너스 — 도구 비교 (학습 목표 충족)

씬 1을 무료 도구로 한 번 더 제작해 비교:
- 이미지: **Gemini (Nano Banana 2)** 동일 프롬프트
- 영상: **Kling 3.0** I2V

비교 항목: 모션 자연스러움 / 색 톤 일치 / 마스터 병 일관성 / 생성 속도 → 표로 기록.
