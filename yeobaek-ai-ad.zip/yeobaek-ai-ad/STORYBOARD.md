# 스토리보드 — 여백 YEOBAEK

> 정식 제출본(PDF): [`docs/여백_스토리보드.pdf`](docs/) · 프롬프트 전문: [PROMPTS.md](PROMPTS.md)

## 1. 브랜드 아이덴티티

- **브랜드명:** 여백 (YEOBAEK) — "비워야 채워진다"는 한국적 여백미에서 출발
- **한 줄 정의:** 오미자·유자 보태니컬을 담은 무가당 스파클링 토닉 (RTD 음료)
- **타겟:** 25–35세 도시 직장인 — 에너지드링크의 각성/크래시, 과당 음료의 죄책감에 지친 사람
- **톤앤매너:** 미니멀 · 한국적 여백미 · 자연광 · 시네마틱 · 차분한 프리미엄
- **USP:** "각성이 아니라 리셋." 카페인 의존 대신 한 박자 쉬어가는 무가당 보태니컬 토닉
- **핵심 메시지(한 문장):** 바쁜 하루에, 여백 한 모금.
- **슬로건 / CTA:** "오늘의 여백을 마시다" / "편의점에서 만나요"
- **색 팔레트:** `#F4F1EA` Mist Ivory · `#3F5249` Sage · `#E8B84B` Yuzu (전 씬 공통 고정)

## 2. 캠페인 목표 & 스토리라인

- **1차 목표(인지):** "각성 대신 리셋" 세계관과 USP를 10초 안에 각인
- **2차 목표(전환):** 마지막 3~5초 CTA로 "편의점에서 찾아보게" 만들기
- **구조(기승전결):** 기(문제) → 승(전환) → 전(해결) → 결(브랜드)
- **연출 장치:** 감정선을 색으로 설계 — 씬1 회색(압박) → 씬3부터 채도 복귀(해방)

## 3. 사용 도구 (2026.06)

| 역할 | 주력 | 대체 |
|---|---|---|
| 이미지 | Grok Imagine (Aurora) | Gemini, Midjourney |
| 비디오(I2V) | Grok Imagine Video 1.5 | Kling 3.0, Runway, Veo 3.1 |
| 오디오(음악·SFX) | Grok 네이티브 오디오 | Suno, ElevenLabs |
| 내레이션 | ElevenLabs / Typecast | Grok 네이티브, Google/MS TTS |
| 통합 편집 | CapCut / DaVinci | Premiere Pro |

> 선택 이유·근거는 [README](README.md#사용-도구-202606-기준) 및 PDF 참고.

---

## 4. 씬별 스토리보드

### 씬 1 — 기 · 문제 제시 (2.5초)

| 필드 | 내용 |
|---|---|
| 목표 메시지 | 쉴 틈 없는 도시의 압박을 한 컷에 보여준다 |
| 화면 구성 | 하이앵글 / 익명의 출근 군중 / 차가운 형광등 지하철 / 회색조 / 빠른 컷 / 텍스트=화면 카피 1줄 |
| 내레이션·카피 | (화면 카피) "숨 쉴 틈, 있으세요?" |
| 사용 도구·목적 | 이미지 Grok(키비주얼) · 영상 Grok I2V(군중 흐름) · 오디오 Grok 네이티브(도시 앰비언트) |
| 입력 프롬프트 | `High-angle shot of a crowded Seoul subway platform at morning rush hour, blurred commuters, cold fluorescent lighting, desaturated gray tones, cinematic 35mm film grain, 16:9` |
| 출력 요약 | 차갑고 빽빽한 도시 압박감의 키비주얼 확보 |
| 파일 | `s01_city_rush.png` / `s01_city_rush.mp4` / `s01_amb_tense.wav` |

### 씬 2 — 승 · 전환 (2.5초)

| 필드 | 내용 |
|---|---|
| 목표 메시지 | 여백 한 병이 등장하며 장면의 속도가 바뀐다 |
| 화면 구성 | 클로즈업 / 병을 집는 손 / 흐릿한 사무실·카페 배경 / 탄산 기포 상승 / 텍스트=짧은 카피 |
| 내레이션·카피 | (화면 카피) "잠깐." |
| 사용 도구·목적 | 이미지 Grok(제품+손) · 영상 Grok I2V(push-in+기포) · 오디오 Grok 네이티브(탄산 SFX+BGM) |
| 입력 프롬프트 | `Close-up, a hand reaching for a minimalist frosted-glass sparkling tonic bottle, sage label, rising bubbles, soft natural window light, muted ivory and sage palette, shallow DOF, cinematic, 16:9` |
| 출력 요약 | 제품 등장과 '쉼'으로의 전환 컷 확보 |
| 파일 | `s02_pickup.png` / `s02_pickup.mp4` / `s02_fizz_sfx.wav` |

> **프롬프트 수정 전/후 로그** → [PROMPTS.md 씬 2](PROMPTS.md#씬-2--승--전환)

### 씬 3 — 전 · 해결 (2.5초)

| 필드 | 내용 |
|---|---|
| 목표 메시지 | 한 모금에 색·호흡이 돌아오는 '리셋'을 감각적으로 전달 |
| 화면 구성 | 미디엄 클로즈업 / 한 모금 후 눈 감고 숨 내쉬는 실루엣 / 안개빛 창가 자연광 / 회색→세이지·아이보리 색 복귀 / 텍스트=없음 |
| 내레이션·카피 | (내레이션) "바쁜 하루에, 여백 한 모금." |
| 사용 도구·목적 | 이미지 Grok · 영상 Grok I2V(빛 변화) · 오디오 ElevenLabs/Typecast TTS(한국어)+Grok 네이티브(앰비언트) |
| 입력 프롬프트 | `Medium close-up silhouette taking a sip and exhaling with eyes closed by a misty window, warm light blooming, color shifting gray to sage and ivory, serene, cinematic, 16:9` |
| 출력 요약 | '리셋' 감정선의 핵심 컷, 색 복귀로 전환 강조 |
| 파일 | `s03_sip_breath.png` / `s03_sip_breath.mp4` / `s03_vo_ko.wav` |

### 씬 4 — 결 · 브랜드 인지 (2.5초)

| 필드 | 내용 |
|---|---|
| 목표 메시지 | 브랜드를 각인시키고 행동을 유도한다 (마지막 3~5초 인지 장치) |
| 화면 구성 | 센터 정렬 제품 히어로샷 / 안개빛 배경 / 상단 로고 / 하단 슬로건+CTA / 텍스트=있음 |
| 내레이션·카피 | (카피) "여백 — 오늘의 여백을 마시다" · (CTA) "편의점에서 만나요" |
| 사용 도구·목적 | 이미지 Grok(히어로샷) · 영상 Grok I2V(기포 루프) · 오디오 Grok 네이티브 · 로고/CTA는 편집 단계 오버레이 |
| 입력 프롬프트 | `Centered product hero shot of a frosted sparkling tonic bottle on a misty ivory background, soft studio light, generous negative space for text, premium minimal, 16:9` |
| 출력 요약 | 로고·슬로건·CTA가 또렷한 브랜드 엔딩 프레임 확보 |
| 파일 | `s04_hero_logo.png` / `s04_hero_logo.mp4` / `s04_brand_sting.wav` |

---

## 5. 일관성 & 크레딧 전략

**일관성**
- 색 팔레트 3색 고정 + 모든 프롬프트에 동일 스타일 토큰 삽입
- 마스터 병 1장을 모든 씬 I2V의 시작 프레임으로 사용 (그록 일관성 한계 보완)
- 무료 대체로 Midjourney 사용 시 `--sref`/`--cref` 병행 가능

**크레딧 절약 (택1+ 적용)**
- 6씬 → 4씬 압축으로 메시지 밀도 ↑
- 정지 이미지 + 짧은 모션(push-in·팬·기포 루프) 중심
- 스타일 레퍼런스 고정으로 재생성 횟수 ↓
- 영상 변환은 씬당 1~2회만 시도

## 6. 최종 영상 스펙

| 항목 | 값 |
|---|---|
| 파일명 | `YEOBAEK_branding_video.mp4` |
| 길이 / 해상도 | 10초 / 1280×720 (16:9) — 그록 최대 720p, 과제 저사양 허용 충족 |
| 프레임레이트 | 24fps |
| 코덱 | H.264 / AAC |
